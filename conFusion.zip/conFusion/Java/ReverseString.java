import java.util.*;
class ReverseString{
    public static void main(String[]args){
        Scanner x=new Scanner(System.in);
        String original=x.nextLine();
        String reverse="";
        for(int i=original.length()-1;i>=0;i--){
            reverse=reverse+original.charAt(i);

            
        }
        
        System.out.println(reverse);

}
}